import React from 'react'

const About = () => {
  return (
    <div>

      <h1>About Students</h1>

      <p>
        1. Student life is considered the golden age of life.<br />

        2. It is the time to build a better future for ourselves.<br />

        3. Student life gives you amazing and beautiful memories.<br />

        4. The most important thing for a student to do is to study and learn.<br />

        5. Student life has a big effect on the whole life of a person.<br />

        6. As a student, life can sometimes be busy and hard.<br />

        7. This stage shapes the personality of a person.<br />

        8. Student life is quite enjoyable because there are fewer struggles.<br />

        9. Our personality and character depend on this stage of life.<br />

        10. We should enjoy and utilize student life as much as we can.<br />
      </p>
    </div>
  )
}

export default About